# Magisk Module for disabling LG lgatcmd

Prevents Android from continuously attempting to start the service even when the package is uninstalled.

Works by injecting an override for the LG lgatcmd service into the boot image.

Download here: https://github.com/null-dev/lg-v60-lgatcmd-disable-magisk/raw/master/lg-v60-lgatcmd-disable-magisk.zip
